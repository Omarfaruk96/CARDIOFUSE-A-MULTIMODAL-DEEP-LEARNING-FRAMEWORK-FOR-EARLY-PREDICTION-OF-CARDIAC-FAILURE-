#!/usr/bin/env python3
"""
CardioFuse: multimodal deep learning for early prediction of cardiac failure.

Fuses three modalities:
  1. EHR tabular features  (ECHD v2: 334 patients, 20 clinical features)
  2. 12-lead ECG images     (synthetic, label-conditioned)
  3. Wearable heart-rate    (synthetic time series, label-conditioned)

Three architectures are trained and compared:
  (1) cnn_only        - ResNet-18 on ECG images only (baseline)
  (2) multimodal      - EHR-MLP + ResNet-18 + LSTM, concatenation fusion
  (3) multimodal_attn - same encoders, multi-head self-attention fusion
                        (dynamic modality weighting)

Split: 64% train / 16% validation / 20% test (stratified).

Usage:
    python cardiofuse.py --data data/ECHD_v2.csv --target <label_column>
    python cardiofuse.py --demo          # runs on a fully synthetic EHR table
"""
from __future__ import annotations

import argparse
import copy
import json
import random
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import LabelEncoder, OneHotEncoder, StandardScaler
from torch.utils.data import DataLoader, Dataset
from torchvision.models import ResNet18_Weights, resnet18

N_LEADS = 12
HR_LEN = 60  # one reading per minute for an hour


# --------------------------------------------------------------------------- #
# Reproducibility
# --------------------------------------------------------------------------- #
def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


# --------------------------------------------------------------------------- #
# Data: EHR
# --------------------------------------------------------------------------- #
def make_demo_ehr(n: int = 334, seed: int = 0) -> pd.DataFrame:
    """Fully synthetic stand-in for ECHD v2 (334 rows, 20 features + target)."""
    rng = np.random.default_rng(seed)
    y = rng.binomial(1, 0.45, n)
    df = pd.DataFrame(
        {
            "age": rng.normal(55 + 8 * y, 11, n).round(),
            "sex": rng.choice(["M", "F"], n),
            "bmi": rng.normal(26 + 2 * y, 4, n),
            "systolic_bp": rng.normal(122 + 12 * y, 15, n),
            "diastolic_bp": rng.normal(78 + 6 * y, 9, n),
            "heart_rate": rng.normal(72 + 8 * y, 10, n),
            "cholesterol": rng.normal(190 + 25 * y, 35, n),
            "ldl": rng.normal(110 + 20 * y, 28, n),
            "hdl": rng.normal(52 - 6 * y, 10, n),
            "triglycerides": rng.normal(145 + 30 * y, 45, n),
            "glucose": rng.normal(100 + 18 * y, 22, n),
            "creatinine": rng.normal(0.95 + 0.2 * y, 0.25, n),
            "bnp": rng.gamma(2.0 + 2.5 * y, 60, n),
            "ejection_fraction": rng.normal(58 - 14 * y, 8, n),
            "smoker": rng.binomial(1, 0.25 + 0.15 * y),
            "diabetes": rng.binomial(1, 0.20 + 0.20 * y),
            "hypertension": rng.binomial(1, 0.35 + 0.25 * y),
            "family_history": rng.binomial(1, 0.20 + 0.15 * y),
            "chest_pain": rng.choice(["none", "atypical", "typical"], n),
            "physical_activity": rng.choice(["low", "moderate", "high"], n),
            "cardiac_failure": y,
        }
    )
    return df


def load_ehr(path: str | None, target: str, demo: bool):
    if demo or not path:
        print("[info] Using synthetic demo EHR table (not real patient data).")
        df = make_demo_ehr()
        target = "cardiac_failure"
    else:
        if not Path(path).exists():
            raise FileNotFoundError(f"Dataset not found: {path}. Use --demo to test the pipeline.")
        df = pd.read_csv(path)
        if target not in df.columns:
            raise ValueError(f"Target column '{target}' not in {list(df.columns)}")
    y = LabelEncoder().fit_transform(df[target])
    if len(np.unique(y)) != 2:
        raise ValueError("This script expects a binary target.")
    X = df.drop(columns=[target])
    return X, y.astype(np.float32)


def build_ehr_preprocessor(X: pd.DataFrame) -> ColumnTransformer:
    num = X.select_dtypes(include=np.number).columns.tolist()
    cat = [c for c in X.columns if c not in num]
    return ColumnTransformer(
        [
            ("num", Pipeline([("imp", SimpleImputer(strategy="median")), ("sc", StandardScaler())]), num),
            (
                "cat",
                Pipeline(
                    [
                        ("imp", SimpleImputer(strategy="most_frequent")),
                        ("oh", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
                    ]
                ),
                cat,
            ),
        ]
    )


# --------------------------------------------------------------------------- #
# Data: synthetic ECG images and wearable heart-rate sequences
# --------------------------------------------------------------------------- #
def _gauss(t: np.ndarray, mu: float, sigma: float, amp: float) -> np.ndarray:
    return amp * np.exp(-0.5 * ((t - mu) / sigma) ** 2)


def _beat(t: np.ndarray, st_shift: float, t_amp: float) -> np.ndarray:
    """One PQRST complex centred at t=0 (seconds)."""
    return (
        _gauss(t, -0.20, 0.025, 0.12)  # P
        + _gauss(t, -0.04, 0.010, -0.15)  # Q
        + _gauss(t, 0.00, 0.012, 1.00)  # R
        + _gauss(t, 0.04, 0.012, -0.25)  # S
        + _gauss(t, 0.15, 0.040, st_shift)  # ST segment
        + _gauss(t, 0.30, 0.060, t_amp)  # T
    )


def synth_ecg_image(label: int, rng: np.random.Generator, size: int = 192) -> np.ndarray:
    """Render a 12-lead ECG-style image (3 x size x size, float32 in [0,1]).

    Failure-class signals have a faster, more irregular rhythm, ST depression,
    flattened T waves and more noise. This is SYNTHETIC and only meant to
    demonstrate the pipeline.
    """
    fs, dur = 100, 2.5
    t = np.arange(0, dur, 1 / fs)
    hr = rng.normal(78 if label else 68, 8)
    rr_jitter = 0.10 if label else 0.03
    st_shift = rng.normal(-0.18 if label else 0.02, 0.05)
    t_amp = rng.normal(0.12 if label else 0.30, 0.06)
    noise = 0.06 if label else 0.03

    beats, tc = [], rng.uniform(0.2, 0.5)
    while tc < dur + 0.3:
        beats.append(tc)
        tc += (60.0 / max(hr, 40)) * (1 + rng.normal(0, rr_jitter))

    img = np.zeros((size, size), dtype=np.float32)
    band = size // N_LEADS
    for lead in range(N_LEADS):
        scale = rng.uniform(0.6, 1.2) * rng.choice([1, 1, 1, -0.6])
        sig = sum(_beat(t - b, st_shift, t_amp) for b in beats) * scale
        sig += rng.normal(0, noise, sig.shape)
        sig = np.interp(np.linspace(0, len(sig) - 1, size), np.arange(len(sig)), sig)
        centre = lead * band + band // 2
        rows = np.clip(centre - (sig * (band * 0.42)), lead * band, (lead + 1) * band - 1).astype(int)
        prev = rows[0]
        for x, r in enumerate(rows):
            lo, hi = min(prev, r), max(prev, r)
            img[lo : hi + 1, x] = 1.0
            prev = r
    # light grid, as on ECG paper
    img[::8, :] = np.maximum(img[::8, :], 0.15)
    img[:, ::8] = np.maximum(img[:, ::8], 0.15)
    return np.repeat(img[None], 3, axis=0)


def synth_wearable_hr(label: int, rng: np.random.Generator, length: int = HR_LEN) -> np.ndarray:
    """Heart-rate series (bpm): failure class has higher mean, more variability and drift."""
    base = rng.normal(82 if label else 70, 6)
    var = 5.5 if label else 3.0
    drift = np.cumsum(rng.normal(0, 0.4 if label else 0.15, length))
    series = base + drift + rng.normal(0, var, length)
    return np.clip(series, 40, 180).astype(np.float32)


# --------------------------------------------------------------------------- #
# Dataset (with augmentation)
# --------------------------------------------------------------------------- #
class MultimodalDataset(Dataset):
    def __init__(self, ehr, ecg, hr, y, augment: bool = False):
        self.ehr = torch.tensor(ehr, dtype=torch.float32)
        self.ecg = torch.tensor(ecg, dtype=torch.float32)
        self.hr = torch.tensor(hr, dtype=torch.float32)
        self.y = torch.tensor(y, dtype=torch.float32)
        self.augment = augment

    def __len__(self):
        return len(self.y)

    def __getitem__(self, i):
        ehr, ecg, hr = self.ehr[i].clone(), self.ecg[i].clone(), self.hr[i].clone()
        if self.augment:
            ehr = ehr + 0.05 * torch.randn_like(ehr)
            shift = int(torch.randint(-10, 11, (1,)))
            ecg = torch.roll(ecg, shifts=shift, dims=2)  # horizontal shift
            ecg = (ecg * (0.9 + 0.2 * torch.rand(1)) + 0.03 * torch.randn_like(ecg)).clamp(0, 1)
            hr = hr * (0.97 + 0.06 * torch.rand(1)) + 0.5 * torch.randn_like(hr)
        hr = ((hr - 75.0) / 15.0).unsqueeze(-1)  # (T, 1), roughly standardised
        return ehr, ecg, hr, self.y[i]


# --------------------------------------------------------------------------- #
# Models
# --------------------------------------------------------------------------- #
class ECGEncoder(nn.Module):
    """ResNet-18 backbone producing a d-dimensional ECG embedding."""

    def __init__(self, out_dim: int, pretrained: bool = False):
        super().__init__()
        backbone = resnet18(weights=ResNet18_Weights.DEFAULT if pretrained else None)
        backbone.fc = nn.Identity()
        self.backbone = backbone
        self.proj = nn.Sequential(nn.Linear(512, out_dim), nn.ReLU(), nn.Dropout(0.3))

    def forward(self, x):
        return self.proj(self.backbone(x))


class CNNOnly(nn.Module):
    """(1) Baseline: ECG images only."""

    def __init__(self, dim: int = 64, pretrained: bool = False, **_):
        super().__init__()
        self.enc = ECGEncoder(dim, pretrained)
        self.head = nn.Linear(dim, 1)

    def forward(self, ehr, ecg, hr):
        return self.head(self.enc(ecg)).squeeze(-1), None


class CardioFuse(nn.Module):
    """(2)/(3) Multimodal EHR + ECG + wearable network.

    use_attention=False -> concatenation fusion
    use_attention=True  -> multi-head self-attention over the three modality tokens
    """

    def __init__(self, ehr_dim: int, dim: int = 64, heads: int = 4, use_attention: bool = True,
                 pretrained: bool = False):
        super().__init__()
        self.use_attention = use_attention
        self.ehr_enc = nn.Sequential(
            nn.Linear(ehr_dim, 128), nn.ReLU(), nn.Dropout(0.3), nn.Linear(128, dim), nn.ReLU()
        )
        self.ecg_enc = ECGEncoder(dim, pretrained)
        self.lstm = nn.LSTM(1, 64, batch_first=True, bidirectional=True)
        self.hr_proj = nn.Sequential(nn.Linear(128, dim), nn.ReLU(), nn.Dropout(0.3))

        if use_attention:
            self.attn = nn.MultiheadAttention(dim, heads, dropout=0.1, batch_first=True)
            self.norm = nn.LayerNorm(dim)
            self.head = nn.Sequential(nn.Linear(dim, 32), nn.ReLU(), nn.Dropout(0.3), nn.Linear(32, 1))
        else:
            self.head = nn.Sequential(nn.Linear(3 * dim, 32), nn.ReLU(), nn.Dropout(0.3), nn.Linear(32, 1))

    def forward(self, ehr, ecg, hr):
        e = self.ehr_enc(ehr)
        c = self.ecg_enc(ecg)
        _, (h, _) = self.lstm(hr)
        w = self.hr_proj(torch.cat([h[-2], h[-1]], dim=1))  # fwd + bwd final states

        if not self.use_attention:
            return self.head(torch.cat([e, c, w], dim=1)).squeeze(-1), None

        tokens = torch.stack([e, c, w], dim=1)  # (B, 3, d)
        out, weights = self.attn(tokens, tokens, tokens, need_weights=True)
        out = self.norm(tokens + out)
        # weights: (B, queries, keys) -> importance each modality receives as a key
        modality_weights = weights.mean(dim=1)  # (B, 3)
        return self.head(out.mean(dim=1)).squeeze(-1), modality_weights


# --------------------------------------------------------------------------- #
# Training / evaluation
# --------------------------------------------------------------------------- #
@torch.no_grad()
def predict(model, loader, device):
    model.eval()
    probs, ys, attn = [], [], []
    for ehr, ecg, hr, y in loader:
        logits, w = model(ehr.to(device), ecg.to(device), hr.to(device))
        probs.append(torch.sigmoid(logits).cpu())
        ys.append(y)
        if w is not None:
            attn.append(w.cpu())
    attn = torch.cat(attn).numpy() if attn else None
    return torch.cat(probs).numpy(), torch.cat(ys).numpy(), attn


def compute_metrics(y, p, thr=0.5):
    pred = (p >= thr).astype(int)
    return {
        "accuracy": accuracy_score(y, pred),
        "precision": precision_score(y, pred, zero_division=0),
        "recall": recall_score(y, pred, zero_division=0),
        "f1": f1_score(y, pred, zero_division=0),
        "auc": roc_auc_score(y, p) if len(np.unique(y)) > 1 else float("nan"),
    }


def train_model(model, loaders, args, device, name):
    train_dl, val_dl, _ = loaders
    n_pos = float(train_dl.dataset.y.sum())
    pos_weight = torch.tensor((len(train_dl.dataset) - n_pos) / max(n_pos, 1.0), device=device)
    criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight)
    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=1e-2)
    sched = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, factor=0.5, patience=3)

    best_auc, best_state, bad = -1.0, None, 0
    for epoch in range(1, args.epochs + 1):
        model.train()
        total = 0.0
        for ehr, ecg, hr, y in train_dl:
            ehr, ecg, hr, y = ehr.to(device), ecg.to(device), hr.to(device), y.to(device)
            opt.zero_grad()
            logits, _ = model(ehr, ecg, hr)
            loss = criterion(logits, y)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
            total += loss.item() * len(y)
        p, y_val, _ = predict(model, val_dl, device)
        m = compute_metrics(y_val, p)
        sched.step(1 - m["auc"])
        print(f"[{name}] epoch {epoch:03d} | train loss {total / len(train_dl.dataset):.4f} "
              f"| val AUC {m['auc']:.3f} | val F1 {m['f1']:.3f}")
        if m["auc"] > best_auc:
            best_auc, best_state, bad = m["auc"], copy.deepcopy(model.state_dict()), 0
        else:
            bad += 1
            if bad >= args.patience:
                print(f"[{name}] early stopping at epoch {epoch}")
                break
    model.load_state_dict(best_state)
    return model


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
def main():
    ap = argparse.ArgumentParser(description="CardioFuse: multimodal cardiac failure prediction")
    ap.add_argument("--data", default=None, help="Path to ECHD v2 CSV")
    ap.add_argument("--target", default="target", help="Name of the binary label column")
    ap.add_argument("--demo", action="store_true", help="Use a fully synthetic EHR table")
    ap.add_argument("--epochs", type=int, default=40)
    ap.add_argument("--patience", type=int, default=8)
    ap.add_argument("--batch-size", type=int, default=16)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--img-size", type=int, default=192)
    ap.add_argument("--pretrained", action="store_true", help="ImageNet-pretrained ResNet-18 (downloads weights)")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", default="results")
    args = ap.parse_args()

    set_seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    print(f"[info] device: {device}")

    # ---- data -------------------------------------------------------------
    X, y = load_ehr(args.data, args.target, args.demo)
    n = len(y)
    rng = np.random.default_rng(args.seed)
    ecg = np.stack([synth_ecg_image(int(l), rng, args.img_size) for l in y])
    hr = np.stack([synth_wearable_hr(int(l), rng) for l in y])

    # stratified 64 / 16 / 20 split
    idx = np.arange(n)
    trval, test = train_test_split(idx, test_size=0.20, stratify=y, random_state=args.seed)
    train, val = train_test_split(trval, test_size=0.20, stratify=y[trval], random_state=args.seed)
    print(f"[info] split sizes -> train {len(train)} | val {len(val)} | test {len(test)}")

    pre = build_ehr_preprocessor(X)
    pre.fit(X.iloc[train])  # fit on training data only (no leakage)
    ehr = {k: pre.transform(X.iloc[ix]).astype(np.float32) for k, ix in
           {"train": train, "val": val, "test": test}.items()}
    ehr_dim = ehr["train"].shape[1]

    def make_loader(name, ix, aug, shuffle):
        ds = MultimodalDataset(ehr[name], ecg[ix], hr[ix], y[ix], augment=aug)
        return DataLoader(ds, batch_size=args.batch_size, shuffle=shuffle)

    loaders = (make_loader("train", train, True, True),
               make_loader("val", val, False, False),
               make_loader("test", test, False, False))

    # ---- models -----------------------------------------------------------
    configs = {
        "cnn_only": lambda: CNNOnly(pretrained=args.pretrained),
        "multimodal": lambda: CardioFuse(ehr_dim, use_attention=False, pretrained=args.pretrained),
        "multimodal_attn": lambda: CardioFuse(ehr_dim, use_attention=True, pretrained=args.pretrained),
    }

    results, rocs, modality_attn = {}, {}, None
    for name, build in configs.items():
        set_seed(args.seed)
        model = build().to(device)
        model = train_model(model, loaders, args, device, name)
        p, y_test, attn = predict(model, loaders[2], device)
        results[name] = compute_metrics(y_test, p)
        results[name]["confusion_matrix"] = confusion_matrix(y_test, (p >= 0.5).astype(int)).tolist()
        rocs[name] = roc_curve(y_test, p)
        if attn is not None:
            modality_attn = attn.mean(axis=0)
        torch.save(model.state_dict(), out / f"{name}.pt")
        print(f"[{name}] TEST -> " + " | ".join(
            f"{k} {v:.3f}" for k, v in results[name].items() if k != "confusion_matrix"))

    # ---- outputs ----------------------------------------------------------
    (out / "metrics.json").write_text(json.dumps(results, indent=2))
    table = pd.DataFrame({k: {m: v[m] for m in ("accuracy", "precision", "recall", "f1", "auc")}
                          for k, v in results.items()}).T.round(4)
    table.to_csv(out / "comparison.csv")
    print("\n=== Test-set comparison ===\n", table.to_string())

    plt.figure(figsize=(5.5, 5))
    for name, (fpr, tpr, _) in rocs.items():
        plt.plot(fpr, tpr, label=f"{name} (AUC={results[name]['auc']:.3f})")
    plt.plot([0, 1], [0, 1], "k--", lw=0.8)
    plt.xlabel("False positive rate")
    plt.ylabel("True positive rate")
    plt.title("ROC curves (test set)")
    plt.legend(loc="lower right")
    plt.tight_layout()
    plt.savefig(out / "roc_curves.png", dpi=200)
    plt.close()

    if modality_attn is not None:
        plt.figure(figsize=(4.5, 3.5))
        plt.bar(["EHR", "ECG", "Wearable"], modality_attn, color=["#4C78A8", "#F58518", "#54A24B"])
        plt.ylabel("Mean attention weight")
        plt.title("Learned modality weighting")
        plt.tight_layout()
        plt.savefig(out / "modality_attention.png", dpi=200)
        plt.close()

    print(f"\n[done] artifacts saved to: {out.resolve()}")


if __name__ == "__main__":
    main()
